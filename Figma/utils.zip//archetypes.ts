export interface Archetype {
  id: string;
  name: string;
  color: string;
  particleColor: string;
  icon: string;
  introLine: string;
  empathyLine: string;
  particleBehavior: {
    speed: number;
    density: number;
    direction: number;
  };
  matchRules: {
    camera?: number;
    battery?: number;
    performance?: number;
    design?: number;
    innovation?: number;
    simplicity?: number;
    durability?: number;
  };
}

export const archetypes: Archetype[] = [
  {
    id: 'visionary',
    name: 'Visionary Photographer',
    color: 'linear-gradient(135deg, #00D4FF 0%, #4D4DFF 100%)',
    particleColor: '#00D4FF',
    icon: '📸',
    introLine: 'You see the world in frames.',
    empathyLine: 'This phone understands your eye.',
    particleBehavior: {
      speed: 1.2,
      density: 80,
      direction: 45
    },
    matchRules: {
      camera: 10,
      innovation: 8,
      design: 7
    }
  },
  {
    id: 'creator',
    name: 'Digital Creator',
    color: 'linear-gradient(135deg, #C07CFF 0%, #FF6B9D 100%)',
    particleColor: '#C07CFF',
    icon: '🎨',
    introLine: 'You bring ideas to life.',
    empathyLine: 'This device amplifies your creativity.',
    particleBehavior: {
      speed: 1.5,
      density: 100,
      direction: 90
    },
    matchRules: {
      performance: 9,
      camera: 8,
      innovation: 8
    }
  },
  {
    id: 'guardian',
    name: 'Pragmatic Guardian',
    color: 'linear-gradient(135deg, #4ADE80 0%, #22D3EE 100%)',
    particleColor: '#4ADE80',
    icon: '🛡️',
    introLine: 'You value reliability above all.',
    empathyLine: 'This phone won\'t let you down.',
    particleBehavior: {
      speed: 0.8,
      density: 60,
      direction: 180
    },
    matchRules: {
      durability: 10,
      battery: 9,
      simplicity: 7
    }
  },
  {
    id: 'explorer',
    name: 'Adventurous Explorer',
    color: 'linear-gradient(135deg, #FBBF24 0%, #F59E0B 100%)',
    particleColor: '#FBBF24',
    icon: '🌍',
    introLine: 'You chase horizons.',
    empathyLine: 'This companion keeps up with your journey.',
    particleBehavior: {
      speed: 1.8,
      density: 90,
      direction: 270
    },
    matchRules: {
      battery: 9,
      camera: 8,
      durability: 8
    }
  },
  {
    id: 'strategist',
    name: 'Tech Strategist',
    color: 'linear-gradient(135deg, #8B5CF6 0%, #6366F1 100%)',
    particleColor: '#8B5CF6',
    icon: '⚡',
    introLine: 'You demand peak performance.',
    empathyLine: 'This machine matches your intensity.',
    particleBehavior: {
      speed: 2.0,
      density: 110,
      direction: 315
    },
    matchRules: {
      performance: 10,
      innovation: 9,
      battery: 7
    }
  },
  {
    id: 'minimalist',
    name: 'Elegant Minimalist',
    color: 'linear-gradient(135deg, #F5F5F5 0%, #E5E5E5 100%)',
    particleColor: '#E5E5E5',
    icon: '✨',
    introLine: 'You appreciate refined simplicity.',
    empathyLine: 'This device embodies quiet perfection.',
    particleBehavior: {
      speed: 0.6,
      density: 40,
      direction: 135
    },
    matchRules: {
      design: 10,
      simplicity: 10,
      innovation: 6
    }
  },
  {
    id: 'performer',
    name: 'Power Performer',
    color: 'linear-gradient(135deg, #EF4444 0%, #F97316 100%)',
    particleColor: '#EF4444',
    icon: '🎮',
    introLine: 'You play at the highest level.',
    empathyLine: 'This powerhouse was built for victory.',
    particleBehavior: {
      speed: 2.2,
      density: 120,
      direction: 0
    },
    matchRules: {
      performance: 10,
      battery: 8,
      innovation: 7
    }
  }
];

export function calculateArchetype(answers: Record<string, any>): Archetype {
  const scores: Record<string, number> = {};
  
  archetypes.forEach(archetype => {
    let score = 0;
    Object.entries(answers).forEach(([key, value]) => {
      if (archetype.matchRules[key as keyof typeof archetype.matchRules]) {
        score += (archetype.matchRules[key as keyof typeof archetype.matchRules] || 0) * (value as number);
      }
    });
    scores[archetype.id] = score;
  });
  
  const topArchetypeId = Object.entries(scores).reduce((a, b) => a[1] > b[1] ? a : b)[0];
  return archetypes.find(a => a.id === topArchetypeId) || archetypes[0];
}
