export interface Question {
  id: string;
  text: string;
  answers: {
    text: string;
    values: Record<string, number>;
  }[];
}

export const questions: Question[] = [
  {
    id: 'priority',
    text: 'What moves you most?',
    answers: [
      {
        text: 'Capturing perfect moments',
        values: { camera: 1.0, design: 0.5 }
      },
      {
        text: 'Raw power and speed',
        values: { performance: 1.0, innovation: 0.6 }
      },
      {
        text: 'All-day reliability',
        values: { battery: 1.0, durability: 0.7 }
      },
      {
        text: 'Timeless aesthetics',
        values: { design: 1.0, simplicity: 0.8 }
      }
    ]
  },
  {
    id: 'usage',
    text: 'How do you truly use your phone?',
    answers: [
      {
        text: 'Creating content daily',
        values: { camera: 0.9, performance: 0.7 }
      },
      {
        text: 'Gaming and entertainment',
        values: { performance: 1.0, battery: 0.6 }
      },
      {
        text: 'Essential tasks only',
        values: { simplicity: 1.0, battery: 0.8 }
      },
      {
        text: 'Everything, everywhere',
        values: { performance: 0.7, battery: 0.9, durability: 0.6 }
      }
    ]
  },
  {
    id: 'values',
    text: 'What do you value in technology?',
    answers: [
      {
        text: 'Cutting-edge innovation',
        values: { innovation: 1.0, performance: 0.6 }
      },
      {
        text: 'Proven reliability',
        values: { durability: 1.0, simplicity: 0.7 }
      },
      {
        text: 'Beautiful design',
        values: { design: 1.0, simplicity: 0.5 }
      },
      {
        text: 'Practical longevity',
        values: { battery: 0.8, durability: 0.9 }
      }
    ]
  },
  {
    id: 'personality',
    text: 'Which resonates with your soul?',
    answers: [
      {
        text: 'I seek perfection',
        values: { camera: 0.8, design: 0.9 }
      },
      {
        text: 'I chase experiences',
        values: { camera: 0.7, battery: 0.8, innovation: 0.5 }
      },
      {
        text: 'I optimize everything',
        values: { performance: 0.9, innovation: 0.8 }
      },
      {
        text: 'I value peace',
        values: { simplicity: 1.0, design: 0.6 }
      }
    ]
  },
  {
    id: 'dealbreaker',
    text: 'What would break the bond?',
    answers: [
      {
        text: 'Poor camera quality',
        values: { camera: 1.0 }
      },
      {
        text: 'Sluggish performance',
        values: { performance: 1.0 }
      },
      {
        text: 'Dies too quickly',
        values: { battery: 1.0 }
      },
      {
        text: 'Feels fragile',
        values: { durability: 1.0 }
      }
    ]
  }
];
