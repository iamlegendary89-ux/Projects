export interface Phone {
  id: string;
  name: string;
  brand: string;
  price: number;
  image: string;
  scores: {
    camera: number;
    performance: number;
    battery: number;
    design: number;
    innovation: number;
    simplicity: number;
    durability: number;
  };
  keyFeatures: string[];
  whyLine: string;
}

export const phones: Phone[] = [
  {
    id: 'iphone-15-pro',
    name: 'iPhone 15 Pro',
    brand: 'Apple',
    price: 999,
    image: 'https://images.unsplash.com/photo-1710023038502-ba80a70a9f53?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpcGhvbmUlMjBwcm8lMjBtYXh8ZW58MXx8fHwxNzY0NTIxMTk3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    scores: {
      camera: 9.5,
      performance: 9.8,
      battery: 8.5,
      design: 9.7,
      innovation: 9.2,
      simplicity: 9.8,
      durability: 8.8
    },
    keyFeatures: [
      '48MP ProRAW camera system',
      'A17 Pro chip',
      'Titanium design',
      'Action button'
    ],
    whyLine: 'Premium perfection in every dimension'
  },
  {
    id: 'samsung-s24-ultra',
    name: 'Galaxy S24 Ultra',
    brand: 'Samsung',
    price: 1199,
    image: 'https://images.unsplash.com/photo-1678958274412-563119ec18ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW1zdW5nJTIwZ2FsYXh5JTIwdWx0cmF8ZW58MXx8fHwxNzY0NTIxMTk4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    scores: {
      camera: 9.7,
      performance: 9.6,
      battery: 9.2,
      design: 9.0,
      innovation: 9.5,
      simplicity: 7.5,
      durability: 9.0
    },
    keyFeatures: [
      '200MP camera with AI zoom',
      'S Pen included',
      '5000mAh battery',
      'Galaxy AI features'
    ],
    whyLine: 'Maximum capability, zero compromise'
  },
  {
    id: 'pixel-8-pro',
    name: 'Pixel 8 Pro',
    brand: 'Google',
    price: 899,
    image: 'https://images.unsplash.com/photo-1636633484288-ba18d16271a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb29nbGUlMjBwaXhlbCUyMHNtYXJ0cGhvbmV8ZW58MXx8fHwxNzY0NTA1NDQ4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    scores: {
      camera: 9.8,
      performance: 8.7,
      battery: 8.3,
      design: 8.5,
      innovation: 9.0,
      simplicity: 9.2,
      durability: 8.2
    },
    keyFeatures: [
      'Computational photography leader',
      'Magic Editor',
      '7 years of updates',
      'Pure Android experience'
    ],
    whyLine: 'The camera that thinks like you do'
  },
  {
    id: 'oneplus-12',
    name: 'OnePlus 12',
    brand: 'OnePlus',
    price: 799,
    image: 'https://images.unsplash.com/photo-1652352545956-34c26af007da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbmVwbHVzJTIwc21hcnRwaG9uZXxlbnwxfHx8fDE3NjQ0NjY2MjV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    scores: {
      camera: 8.8,
      performance: 9.5,
      battery: 9.5,
      design: 8.8,
      innovation: 8.5,
      simplicity: 8.8,
      durability: 8.5
    },
    keyFeatures: [
      '100W fast charging',
      '5400mAh battery',
      'Snapdragon 8 Gen 3',
      'Hasselblad camera'
    ],
    whyLine: 'Flagship performance without the flagship price'
  },
  {
    id: 'iphone-15',
    name: 'iPhone 15',
    brand: 'Apple',
    price: 799,
    image: 'https://images.unsplash.com/photo-1726828501829-9188cde81755?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpcGhvbmUlMjBibHVlfGVufDF8fHx8MTc2NDUyMTE5OXww&ixlib=rb-4.1.0&q=80&w=1080',
    scores: {
      camera: 8.8,
      performance: 9.2,
      battery: 8.2,
      design: 9.5,
      innovation: 8.5,
      simplicity: 9.8,
      durability: 8.5
    },
    keyFeatures: [
      'Dynamic Island',
      '48MP main camera',
      'A16 Bionic',
      'All-day battery'
    ],
    whyLine: 'Everything you need, beautifully refined'
  },
  {
    id: 'nothing-phone-2',
    name: 'Nothing Phone (2)',
    brand: 'Nothing',
    price: 599,
    image: 'https://images.unsplash.com/photo-1761907174062-c8baf8b7edb3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmFuc3BhcmVudCUyMHNtYXJ0cGhvbmV8ZW58MXx8fHwxNzY0NTIxMTk5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    scores: {
      camera: 8.2,
      performance: 8.5,
      battery: 8.5,
      design: 9.8,
      innovation: 9.5,
      simplicity: 8.5,
      durability: 7.8
    },
    keyFeatures: [
      'Glyph Interface',
      'Transparent design',
      'Pure Nothing OS',
      'Unique aesthetic'
    ],
    whyLine: 'Design as a statement'
  },
  {
    id: 'rog-phone-7',
    name: 'ROG Phone 7',
    brand: 'ASUS',
    price: 999,
    image: 'https://images.unsplash.com/photo-1688986760609-47835488547a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzbWFydHBob25lfGVufDF8fHx8MTc2NDUyMTE5OXww&ixlib=rb-4.1.0&q=80&w=1080',
    scores: {
      camera: 7.5,
      performance: 10.0,
      battery: 9.8,
      design: 8.0,
      innovation: 8.8,
      simplicity: 6.5,
      durability: 9.2
    },
    keyFeatures: [
      '165Hz AMOLED display',
      '6000mAh battery',
      'AirTriggers',
      'Gaming-first design'
    ],
    whyLine: 'Built for champions'
  },
  {
    id: 'fairphone-5',
    name: 'Fairphone 5',
    brand: 'Fairphone',
    price: 699,
    image: 'https://images.unsplash.com/photo-1584658645175-90788b3347b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2R1bGFyJTIwc21hcnRwaG9uZXxlbnwxfHx8fDE3NjQ1MjEyMDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    scores: {
      camera: 7.8,
      performance: 7.5,
      battery: 8.5,
      design: 8.0,
      innovation: 7.5,
      simplicity: 8.8,
      durability: 10.0
    },
    keyFeatures: [
      'User-repairable',
      '8-10 year lifespan',
      'Ethical sourcing',
      'Modular design'
    ],
    whyLine: 'The phone that respects longevity'
  }
];

export function calculatePhoneMatch(phone: Phone, userValues: Record<string, number>): number {
  let totalScore = 0;
  let totalWeight = 0;

  Object.entries(userValues).forEach(([key, weight]) => {
    const phoneScore = phone.scores[key as keyof typeof phone.scores];
    if (phoneScore !== undefined) {
      totalScore += phoneScore * weight;
      totalWeight += weight;
    }
  });

  return totalWeight > 0 ? (totalScore / totalWeight) * 10 : 0;
}

export function getTopRecommendation(userValues: Record<string, number>): Phone {
  const phonesWithScores = phones.map(phone => ({
    phone,
    matchScore: calculatePhoneMatch(phone, userValues)
  }));

  phonesWithScores.sort((a, b) => b.matchScore - a.matchScore);
  return phonesWithScores[0].phone;
}

export function getAlternatives(userValues: Record<string, number>, excludeId?: string): Array<Phone & { matchScore: number }> {
  const phonesWithScores = phones
    .filter(phone => phone.id !== excludeId)
    .map(phone => ({
      ...phone,
      matchScore: calculatePhoneMatch(phone, userValues)
    }));

  phonesWithScores.sort((a, b) => b.matchScore - a.matchScore);
  return phonesWithScores;
}