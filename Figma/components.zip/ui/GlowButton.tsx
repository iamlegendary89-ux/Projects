import { motion } from 'motion/react';
import { ButtonHTMLAttributes } from 'react';

interface GlowButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
  glowColor?: string;
  children: React.ReactNode;
}

export function GlowButton({ 
  variant = 'primary', 
  glowColor = '#00D4FF',
  children, 
  className = '',
  disabled = false,
  ...props 
}: GlowButtonProps) {
  const baseClasses = 'relative px-8 py-4 rounded-full transition-all duration-150 overflow-hidden';
  
  const variantClasses = {
    primary: 'bg-gradient-to-r from-[#00D4FF] via-[#4D4DFF] to-[#C07CFF] text-white',
    secondary: 'bg-white/5 backdrop-blur-md border-2 border-white/15 text-[#F5F5F5]',
    ghost: 'bg-transparent text-[#F5F5F5] hover:bg-white/5'
  };

  const disabledClasses = disabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer';

  return (
    <motion.button
      className={`${baseClasses} ${variantClasses[variant]} ${disabledClasses} ${className}`}
      whileHover={!disabled ? { scale: 1.02 } : {}}
      whileTap={!disabled ? { scale: 0.98 } : {}}
      disabled={disabled}
      {...props}
    >
      {/* Glow effect */}
      {!disabled && variant === 'primary' && (
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            background: `radial-gradient(circle, ${glowColor}66 0%, transparent 70%)`,
            filter: 'blur(12px)',
            opacity: 0
          }}
          whileHover={{
            opacity: 0.6,
            scale: 1.2
          }}
          transition={{ duration: 0.15 }}
        />
      )}
      
      {/* Secondary glow */}
      {!disabled && variant === 'secondary' && (
        <motion.div
          className="absolute inset-0 rounded-full border-2"
          style={{
            borderColor: glowColor,
            opacity: 0,
            boxShadow: `0 0 8px ${glowColor}88`
          }}
          whileHover={{
            opacity: 0.4
          }}
          transition={{ duration: 0.15 }}
        />
      )}

      {/* Content */}
      <span className="relative z-10">{children}</span>
    </motion.button>
  );
}
