import { motion } from 'motion/react';

interface ProgressBarProps {
  progress: number;
  color?: string;
  className?: string;
}

export function ProgressBar({ progress, color = '#00D4FF', className = '' }: ProgressBarProps) {
  return (
    <div className={`w-full h-1 bg-white/10 rounded-full overflow-hidden ${className}`}>
      <motion.div
        className="h-full rounded-full"
        style={{
          background: `linear-gradient(90deg, ${color} 0%, ${color}cc 100%)`,
          boxShadow: `0 0 8px ${color}88`
        }}
        initial={{ width: 0 }}
        animate={{ width: `${progress}%` }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
      />
    </div>
  );
}
