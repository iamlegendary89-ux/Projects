import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GlassCard } from './ui/GlassCard';
import { ProgressBar } from './ui/ProgressBar';
import { ParticleField } from './ParticleField';
import { questions } from '../utils/questions';
import { Crystal } from './Crystal';

interface GuidedFlowProps {
  onComplete: (answers: Record<string, any>) => void;
  currentArchetype?: { color: string; particleColor: string };
}

export function GuidedFlow({ onComplete, currentArchetype }: GuidedFlowProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    const answer = currentQuestion.answers[answerIndex];
    
    setTimeout(() => {
      const newAnswers = {
        ...answers,
        ...answer.values
      };
      
      Object.keys(answer.values).forEach(key => {
        newAnswers[key] = (newAnswers[key] || 0) + answer.values[key];
      });

      setAnswers(newAnswers);
      
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setSelectedAnswer(null);
      } else {
        setTimeout(() => onComplete(newAnswers), 400);
      }
    }, 400);
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden px-6">
      <ParticleField 
        color={currentArchetype?.particleColor || '#00D4FF'}
        density={60 + (progress / 100) * 40}
        speed={1 + (progress / 100) * 0.5}
      />
      
      {/* Top progress bar */}
      <div className="fixed top-0 left-0 right-0 z-50 p-6">
        <ProgressBar 
          progress={progress} 
          color={currentArchetype?.particleColor || '#00D4FF'}
        />
      </div>

      {/* Archetype formation indicator */}
      <motion.div
        className="fixed top-20 right-6 z-50"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: progress > 20 ? 1 : 0, scale: progress > 20 ? 1 : 0.8 }}
        transition={{ duration: 0.5 }}
      >
        <Crystal 
          archetype={currentArchetype}
          confidence={progress}
          className="scale-50"
        />
      </motion.div>

      {/* Question card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestionIndex}
          className="relative z-10 w-full max-w-3xl"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          transition={{ duration: 0.3 }}
        >
          <GlassCard className="p-12">
            <motion.h2
              className="mb-12 text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              {currentQuestion.text}
            </motion.h2>

            <div className="grid gap-4">
              {currentQuestion.answers.map((answer, index) => (
                <motion.button
                  key={index}
                  className="relative px-8 py-6 rounded-2xl border-2 transition-all duration-150 text-left overflow-hidden group"
                  style={{
                    borderColor: selectedAnswer === index 
                      ? currentArchetype?.particleColor || '#00D4FF'
                      : 'rgba(255, 255, 255, 0.15)',
                    background: selectedAnswer === index
                      ? `${currentArchetype?.particleColor || '#00D4FF'}22`
                      : 'rgba(255, 255, 255, 0.03)'
                  }}
                  onClick={() => handleAnswerSelect(index)}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + index * 0.05 }}
                  whileHover={{ scale: 1.01, y: -2 }}
                  whileTap={{ scale: 0.99 }}
                >
                  {/* Hover glow */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-150"
                    style={{
                      background: `radial-gradient(circle at center, ${currentArchetype?.particleColor || '#00D4FF'}22 0%, transparent 70%)`,
                    }}
                  />
                  
                  <span className="relative z-10 block text-lg">{answer.text}</span>
                </motion.button>
              ))}
            </div>
          </GlassCard>

          {/* Question counter */}
          <motion.div
            className="text-center mt-8 text-sm opacity-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            transition={{ delay: 0.3 }}
          >
            Question {currentQuestionIndex + 1} of {questions.length}
          </motion.div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
