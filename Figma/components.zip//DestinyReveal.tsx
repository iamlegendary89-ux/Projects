import { motion } from 'motion/react';
import { GlowButton } from './ui/GlowButton';
import { ParticleField } from './ParticleField';
import { ArchetypeBadge } from './ArchetypeBadge';
import { Crystal } from './Crystal';
import { Archetype } from '../utils/archetypes';
import { Phone, calculatePhoneMatch } from '../utils/phones';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface DestinyRevealProps {
  archetype: Archetype;
  recommendedPhone: Phone;
  userValues: Record<string, number>;
  onExplore: () => void;
}

export function DestinyReveal({ archetype, recommendedPhone, userValues, onExplore }: DestinyRevealProps) {
  const matchScore = calculatePhoneMatch(recommendedPhone, userValues);
  const confidence = Math.min(Math.round(matchScore), 99);
  
  // Calculate fate divergence (mock calculation for dramatic effect)
  const fateDivergence = (100 - confidence) * 0.317;

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden px-6 py-20">
      {/* Animated gradient background */}
      <motion.div
        className="fixed inset-0"
        style={{
          background: archetype.color,
          opacity: 0.15
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.15 }}
        transition={{ duration: 1.5 }}
      />
      
      <ParticleField 
        color={archetype.particleColor}
        density={archetype.particleBehavior.density}
        speed={archetype.particleBehavior.speed}
      />
      
      <motion.div
        className="relative z-10 max-w-6xl w-full"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.7 }}
      >
        {/* Header section */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <ArchetypeBadge archetype={archetype} showFull className="mb-8" />
          
          <h1 className="mb-6">The One</h1>
          
          <p className="text-2xl italic opacity-80 mb-2">
            {archetype.empathyLine}
          </p>
        </motion.div>

        {/* Main reveal section */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-12">
          {/* Phone image */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, scale: 0.9, rotateY: -20 }}
            animate={{ opacity: 1, scale: 1, rotateY: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <motion.div
              className="relative"
              animate={{
                rotateY: [0, 5, 0, -5, 0]
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            >
              {/* Glow effect behind phone */}
              <div
                className="absolute inset-0 blur-3xl opacity-50 rounded-3xl"
                style={{
                  background: archetype.color,
                  transform: 'scale(1.1)'
                }}
              />
              
              <div className="relative aspect-[3/4] rounded-3xl overflow-hidden border-2 border-white/20 shadow-2xl">
                <ImageWithFallback
                  src={recommendedPhone.image}
                  alt={recommendedPhone.name}
                  className="w-full h-full object-cover"
                />
              </div>
            </motion.div>
          </motion.div>

          {/* Details */}
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.7, duration: 0.7 }}
          >
            {/* Phone name and brand */}
            <div>
              <div className="text-sm opacity-60 mb-2">{recommendedPhone.brand}</div>
              <h2 className="mb-4">{recommendedPhone.name}</h2>
              <div className="text-3xl mb-2">${recommendedPhone.price}</div>
            </div>

            {/* Confidence meter */}
            <div className="flex items-center gap-6">
              <Crystal 
                archetype={archetype}
                confidence={100}
                className="scale-75"
              />
              <div className="flex-1">
                <div className="flex items-end gap-2 mb-2">
                  <div 
                    className="text-5xl"
                    style={{
                      background: archetype.color,
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent'
                    }}
                  >
                    {confidence}%
                  </div>
                  <div className="text-sm opacity-60 pb-2">Match</div>
                </div>
                <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{ background: archetype.color }}
                    initial={{ width: 0 }}
                    animate={{ width: `${confidence}%` }}
                    transition={{ delay: 1, duration: 1.5, ease: 'easeOut' }}
                  />
                </div>
              </div>
            </div>

            {/* Key features */}
            <div className="space-y-3">
              {recommendedPhone.keyFeatures.map((feature, index) => (
                <motion.div
                  key={index}
                  className="flex items-center gap-3 text-sm"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1 + index * 0.1 }}
                >
                  <div 
                    className="w-1 h-1 rounded-full"
                    style={{ background: archetype.particleColor }}
                  />
                  <span className="opacity-80">{feature}</span>
                </motion.div>
              ))}
            </div>

            {/* Why line */}
            <motion.p
              className="text-lg italic opacity-70 border-l-2 pl-4"
              style={{ borderColor: archetype.particleColor }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.7 }}
              transition={{ delay: 1.5 }}
            >
              {recommendedPhone.whyLine}
            </motion.p>

            {/* Fate divergence */}
            <motion.div
              className="p-4 rounded-xl bg-white/5 border border-white/10"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.7 }}
            >
              <div className="text-xs opacity-50 mb-1">Fate Divergence</div>
              <div className="text-sm">
                Choosing anything else reduces satisfaction by{' '}
                <span 
                  className="font-medium"
                  style={{ color: archetype.particleColor }}
                >
                  −{fateDivergence.toFixed(1)}%
                </span>
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Action buttons */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2 }}
        >
          <GlowButton
            variant="primary"
            glowColor={archetype.particleColor}
            className="min-w-64"
            onClick={() => window.open('https://www.google.com/search?q=' + encodeURIComponent(recommendedPhone.name), '_blank')}
          >
            This is yours
          </GlowButton>
          <GlowButton
            variant="secondary"
            glowColor={archetype.particleColor}
            className="min-w-64"
            onClick={onExplore}
          >
            See alternatives
          </GlowButton>
        </motion.div>
      </motion.div>
    </div>
  );
}
