import { motion } from 'motion/react';

interface CrystalProps {
  archetype?: {
    color: string;
    particleColor: string;
  };
  isPulsing?: boolean;
  confidence?: number;
  className?: string;
}

export function Crystal({ archetype, isPulsing = false, confidence = 0, className = '' }: CrystalProps) {
  const baseColor = archetype?.particleColor || '#00D4FF';
  
  return (
    <div className={`relative ${className}`}>
      <motion.div
        className="relative w-32 h-32 mx-auto"
        animate={{
          rotateY: isPulsing ? [0, 360] : 0,
          rotateX: 10
        }}
        transition={{
          rotateY: {
            duration: 8,
            repeat: Infinity,
            ease: 'linear'
          }
        }}
        style={{
          transformStyle: 'preserve-3d',
          perspective: 1000
        }}
      >
        {/* Crystal core */}
        <motion.div
          className="absolute inset-0"
          style={{
            background: archetype?.color || 'linear-gradient(135deg, #00D4FF 0%, #4D4DFF 100%)',
            clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
            filter: 'blur(1px)',
            opacity: 0.6
          }}
          animate={isPulsing ? {
            scale: [1, 1.05, 1],
            opacity: [0.6, 0.8, 0.6]
          } : {}}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
        />

        {/* Crystal edges */}
        <div
          className="absolute inset-0"
          style={{
            background: 'transparent',
            border: `2px solid ${baseColor}`,
            clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
            boxShadow: `0 0 20px ${baseColor}66, inset 0 0 20px ${baseColor}33`
          }}
        />

        {/* Inner glow */}
        <motion.div
          className="absolute inset-4"
          style={{
            background: `radial-gradient(circle, ${baseColor}88 0%, transparent 70%)`,
          }}
          animate={isPulsing ? {
            scale: [1, 1.2, 1],
            opacity: [0.5, 0.8, 0.5]
          } : {}}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: 0.3
          }}
        />

        {/* Confidence fill */}
        {confidence > 0 && (
          <motion.div
            className="absolute bottom-0 left-0 right-0"
            style={{
              background: archetype?.color || 'linear-gradient(135deg, #00D4FF 0%, #4D4DFF 100%)',
              clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
              transformOrigin: 'bottom'
            }}
            initial={{ scaleY: 0 }}
            animate={{ scaleY: confidence / 100 }}
            transition={{ duration: 1.5, ease: 'easeOut' }}
          />
        )}
      </motion.div>

      {/* Outer glow ring */}
      <motion.div
        className="absolute inset-0 rounded-full"
        style={{
          background: `radial-gradient(circle, transparent 60%, ${baseColor}22 100%)`,
          filter: 'blur(20px)'
        }}
        animate={isPulsing ? {
          scale: [1, 1.3, 1],
          opacity: [0.3, 0.6, 0.3]
        } : {}}
        transition={{
          duration: 2.5,
          repeat: Infinity,
          ease: 'easeInOut'
        }}
      />
    </div>
  );
}
