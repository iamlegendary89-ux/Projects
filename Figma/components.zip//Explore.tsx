import { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { GlassCard } from './ui/GlassCard';
import { ParticleField } from './ParticleField';
import { Archetype } from '../utils/archetypes';
import { Phone, getAlternatives } from '../utils/phones';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ChevronDown } from 'lucide-react';

interface ExploreProps {
  archetype: Archetype;
  userValues: Record<string, number>;
  recommendedPhoneId: string;
}

export function Explore({ archetype, userValues, recommendedPhoneId }: ExploreProps) {
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 2000]);
  const [showFilters, setShowFilters] = useState(false);

  const alternatives = useMemo(() => {
    return getAlternatives(userValues, recommendedPhoneId);
  }, [userValues, recommendedPhoneId]);

  const filteredPhones = useMemo(() => {
    return alternatives.filter(phone => {
      const brandMatch = selectedBrands.length === 0 || selectedBrands.includes(phone.brand);
      const priceMatch = phone.price >= priceRange[0] && phone.price <= priceRange[1];
      return brandMatch && priceMatch;
    });
  }, [alternatives, selectedBrands, priceRange]);

  const brands = useMemo(() => {
    return Array.from(new Set(alternatives.map(p => p.brand)));
  }, [alternatives]);

  const toggleBrand = (brand: string) => {
    setSelectedBrands(prev =>
      prev.includes(brand)
        ? prev.filter(b => b !== brand)
        : [...prev, brand]
    );
  };

  return (
    <div className="relative min-h-screen overflow-hidden px-6 py-20">
      <ParticleField 
        color={archetype.particleColor}
        density={50}
        speed={0.8}
      />
      
      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h2 className="mb-4">The Collection</h2>
          <p className="text-lg opacity-70">
            Other paths that align with your essence
          </p>
        </motion.div>

        {/* Filters toggle */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 mx-auto px-6 py-3 rounded-full bg-white/5 border border-white/15 hover:bg-white/10 transition-colors"
          >
            <span>Filters</span>
            <ChevronDown 
              className="w-4 h-4 transition-transform"
              style={{ transform: showFilters ? 'rotate(180deg)' : 'rotate(0deg)' }}
            />
          </button>

          {/* Filter panel */}
          {showFilters && (
            <motion.div
              className="mt-6 max-w-2xl mx-auto"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <GlassCard className="p-6">
                {/* Brand filters */}
                <div className="mb-6">
                  <div className="text-sm opacity-60 mb-3">Brand</div>
                  <div className="flex flex-wrap gap-2">
                    {brands.map(brand => (
                      <button
                        key={brand}
                        onClick={() => toggleBrand(brand)}
                        className="px-4 py-2 rounded-full border-2 transition-all"
                        style={{
                          borderColor: selectedBrands.includes(brand)
                            ? archetype.particleColor
                            : 'rgba(255, 255, 255, 0.15)',
                          background: selectedBrands.includes(brand)
                            ? `${archetype.particleColor}22`
                            : 'transparent'
                        }}
                      >
                        {brand}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Price range */}
                <div>
                  <div className="text-sm opacity-60 mb-3">
                    Price Range: ${priceRange[0]} - ${priceRange[1]}
                  </div>
                  <div className="flex gap-4">
                    <input
                      type="range"
                      min="0"
                      max="2000"
                      step="100"
                      value={priceRange[0]}
                      onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
                      className="flex-1"
                    />
                    <input
                      type="range"
                      min="0"
                      max="2000"
                      step="100"
                      value={priceRange[1]}
                      onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
                      className="flex-1"
                    />
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          )}
        </motion.div>

        {/* Phone grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          {filteredPhones.map((phone, index) => (
            <motion.div
              key={phone.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.05 }}
            >
              <GlassCard hover className="p-6 h-full">
                {/* Match percentage badge */}
                <div
                  className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs mb-4"
                  style={{
                    background: `${archetype.particleColor}22`,
                    borderColor: archetype.particleColor,
                    border: '1px solid'
                  }}
                >
                  <span 
                    className="font-medium"
                    style={{ color: archetype.particleColor }}
                  >
                    {Math.round(phone.matchScore)}%
                  </span>
                  <span className="opacity-60">match</span>
                </div>

                {/* Phone image */}
                <div className="aspect-[3/4] rounded-xl overflow-hidden mb-4 bg-white/5">
                  <ImageWithFallback
                    src={phone.image}
                    alt={phone.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Phone details */}
                <div className="space-y-2">
                  <div className="text-xs opacity-50">{phone.brand}</div>
                  <h3 className="text-lg">{phone.name}</h3>
                  <div className="text-xl">${phone.price}</div>
                  <p className="text-sm opacity-70 line-clamp-2">
                    {phone.whyLine}
                  </p>
                </div>

                {/* CTA */}
                <button
                  onClick={() => window.open('https://www.google.com/search?q=' + encodeURIComponent(phone.name), '_blank')}
                  className="w-full mt-4 px-4 py-2 rounded-full border-2 transition-all hover:bg-white/5"
                  style={{
                    borderColor: 'rgba(255, 255, 255, 0.15)'
                  }}
                >
                  Learn more
                </button>
              </GlassCard>
            </motion.div>
          ))}
        </motion.div>

        {/* No results */}
        {filteredPhones.length === 0 && (
          <motion.div
            className="text-center py-20 opacity-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
          >
            <p>No phones match your filters</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
