import { motion } from 'motion/react';
import { GlowButton } from './ui/GlowButton';
import { ParticleField } from './ParticleField';

interface LandingProps {
  onBegin: () => void;
}

export function Landing({ onBegin }: LandingProps) {
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <ParticleField density={60} speed={0.8} />
      
      <motion.div
        className="relative z-10 text-center px-6 max-w-2xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.7 }}
      >
        {/* Logo */}
        <motion.div
          className="mb-12"
          animate={{
            opacity: [1, 0.92, 1],
            filter: ['brightness(1)', 'brightness(1.08)', 'brightness(1)']
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
        >
          <h1 className="mb-4 bg-gradient-to-r from-[#00D4FF] via-[#4D4DFF] to-[#C07CFF] bg-clip-text text-transparent">
            SoulMatch
          </h1>
          <div className="w-24 h-1 mx-auto bg-gradient-to-r from-transparent via-[#00D4FF] to-transparent" />
        </motion.div>

        {/* Tagline */}
        <motion.p
          className="text-2xl mb-16 text-[#F5F5F5]/80 italic"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.7 }}
        >
          The one that was waiting for you.
        </motion.p>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.7 }}
        >
          <GlowButton
            onClick={onBegin}
            className="w-full max-w-xs mx-auto h-16"
          >
            Begin
          </GlowButton>
        </motion.div>
      </motion.div>
    </div>
  );
}
