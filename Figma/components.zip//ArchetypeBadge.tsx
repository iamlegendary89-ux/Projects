import { motion } from 'motion/react';
import { Archetype } from '../utils/archetypes';

interface ArchetypeBadgeProps {
  archetype: Archetype;
  showFull?: boolean;
  className?: string;
}

export function ArchetypeBadge({ archetype, showFull = false, className = '' }: ArchetypeBadgeProps) {
  return (
    <motion.div
      className={`inline-flex items-center gap-3 px-6 py-3 rounded-full backdrop-blur-md border-2 ${className}`}
      style={{
        background: `${archetype.color}22`,
        borderColor: archetype.particleColor
      }}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
    >
      <span className="text-2xl">{archetype.icon}</span>
      <div>
        <div className="font-medium">{archetype.name}</div>
        {showFull && (
          <div className="text-sm opacity-75 italic">{archetype.introLine}</div>
        )}
      </div>
    </motion.div>
  );
}
