import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Crystal } from './Crystal';
import { ParticleField } from './ParticleField';
import { Archetype } from '../utils/archetypes';

interface ThinkingProps {
  archetype: Archetype;
  onComplete: () => void;
}

export function Thinking({ archetype, onComplete }: ThinkingProps) {
  const [confidence, setConfidence] = useState(0);
  const [currentPhrase, setCurrentPhrase] = useState(0);

  const phrases = [
    'Analyzing 127 expert reviews',
    'Processing your soul pattern',
    'Calculating destiny alignment',
    'Converging on the truth'
  ];

  useEffect(() => {
    // Confidence animation
    const confidenceInterval = setInterval(() => {
      setConfidence(prev => {
        if (prev >= 100) {
          clearInterval(confidenceInterval);
          return 100;
        }
        return prev + 2;
      });
    }, 80);

    // Phrase rotation
    const phraseInterval = setInterval(() => {
      setCurrentPhrase(prev => (prev + 1) % phrases.length);
    }, 2000);

    // Complete after 8 seconds
    const timer = setTimeout(() => {
      onComplete();
    }, 8000);

    return () => {
      clearInterval(confidenceInterval);
      clearInterval(phraseInterval);
      clearTimeout(timer);
    };
  }, [onComplete]);

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <ParticleField 
        color={archetype.particleColor}
        density={archetype.particleBehavior.density}
        speed={archetype.particleBehavior.speed}
      />
      
      <motion.div
        className="relative z-10 text-center px-6 max-w-2xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.7 }}
      >
        {/* Crystal */}
        <motion.div
          className="mb-12"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.7 }}
        >
          <Crystal 
            archetype={archetype}
            isPulsing={true}
            confidence={confidence}
            className="scale-150"
          />
        </motion.div>

        {/* Status text */}
        <motion.div
          className="space-y-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <motion.p
            key={currentPhrase}
            className="text-xl"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.5 }}
          >
            {phrases[currentPhrase]}
            <motion.span
              animate={{ opacity: [0, 1, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              ...
            </motion.span>
          </motion.p>

          {/* Confidence percentage */}
          <motion.div
            className="text-6xl font-bold bg-gradient-to-r from-[#00D4FF] via-[#4D4DFF] to-[#C07CFF] bg-clip-text text-transparent"
            style={{
              background: archetype.color,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}
          >
            {Math.floor(confidence)}%
          </motion.div>

          <p className="text-sm opacity-50">Confidence</p>
        </motion.div>
      </motion.div>
    </div>
  );
}
